# Documentation

- [Notes on iCalendar Schedules](./icalendar-schedules.md)
- [Permissions](./permissions.md)
- [Generating Database Schema Documentation](./db-schema-documentation-HOWTO.md)
